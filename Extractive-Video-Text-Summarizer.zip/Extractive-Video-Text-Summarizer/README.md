# Extractive Video & Text Summarization using KLSummarizer
### This Project is aimed to be used for Online Lecture Summaries and Content Suggestion Relevant to that lecture topic.
The TextSummarizer file can be used to generate Text based Summary of the given subtitles file<br />
The TextSummarizer even suggests online relevant content available for the topic or title of the video lecture(generates it using subtitles file and not the video file itself)<br />
The VideoSummarizer can be used to generate Video Summary given Video(.mp4) and Subtitles(.srt) files.    

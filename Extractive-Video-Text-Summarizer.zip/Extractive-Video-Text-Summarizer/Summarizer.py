import spacy
from spacy.lang.en.stop_words import STOP_WORDS
from string import punctuation
from heapq import nlargest

text = """

The domains wikipedia.com and wikipedia.org were registered on January 12, 2001,[20] and January 13, 2001,[21] respectively, and Wikipedia was launched on January 15, 2001,[12] as a single English-language edition at www.wikipedia.com,[22] and announced by Sanger on the Nupedia mailing list.[16] Wikipedia's policy of "neutral point-of-view"[23] was codified in its first few months. Otherwise, there were relatively few rules initially and Wikipedia operated independently of Nupedia.[16] Originally, Bomis intended to make Wikipedia a business for profit.[24]


The Wikipedia home page on December 17, 2001
Wikipedia gained early contributors from Nupedia, Slashdot postings, and web search engine indexing. Language editions were also created, with a total of 161 by the end of 2004.[25] Nupedia and Wikipedia coexisted until the former's servers were taken down permanently in 2003, and its text was incorporated into Wikipedia. The English Wikipedia passed the mark of two million articles on September 9, 2007, making it the largest encyclopedia ever assembled, surpassing the Yongle Encyclopedia made during the Ming Dynasty in 1408, which had held the record for almost 600 years.[26]

Citing fears of commercial advertising and lack of control in Wikipedia, users of the Spanish Wikipedia forked from Wikipedia to create the Enciclopedia Libre in February 2002.[27] Wales then announced that Wikipedia would not display advertisements, and changed Wikipedia's domain from wikipedia.com to wikipedia.org.[28][29]

Though the English Wikipedia reached three million articles in August 2009, the growth of the edition, in terms of the numbers of new articles and of contributors, appears to have peaked around early 2007.[30] Around 1,800 articles were added daily to the encyclopedia in 2006; by 2013 that average was roughly 800.[31] A team at the Palo Alto Research Center attributed this slowing of growth to the project's increasing exclusivity and resistance to change.[32] Others suggest that the growth is flattening naturally because articles that could be called "low-hanging fruit"—topics that clearly merit an article—have already been created and built up extensively.[33][34][35]


File:Wikipedia Edit 2014.webm
A promotional video of the Wikimedia Foundation that encourages viewers to edit Wikipedia, mostly reviewing 2014 via Wikipedia content
In November 2009, a researcher at the Rey Juan Carlos University in Madrid found that the English Wikipedia had lost 49,000 editors during the first three months of 2009; in comparison, the project lost only 4,900 editors during the same period in 2008.[36][37] The Wall Street Journal cited the array of rules applied to editing and disputes related to such content among the reasons for this trend.[38] Wales disputed these claims in 2009, denying the decline and questioning the methodology of the study.[39] Two years later, in 2011, Wales acknowledged the presence of a slight decline, noting a decrease from "a little more than 36,000 writers" in June 2010 to 35,800 in June 2011. In the same interview, Wales also claimed the number of editors was "stable and sustainable".[40] A 2013 article titled "The Decline of Wikipedia" in MIT Technology Review questioned this claim. The article revealed that since 2007, Wikipedia had lost a third of its volunteer editors, and those still there have focused increasingly on minutiae.[41] In July 2012, The Atlantic reported that the number of administrators is also in decline.[42] In the November 25, 2013, issue of New York magazine, Katherine Ward stated "Wikipedia, the sixth-most-used website, is facing an internal crisis".[43]

In January 2007, Wikipedia entered for the first time the top-ten list of the most popular websites in the US, according to comscore Networks. With 42.9 million unique visitors, Wikipedia was ranked at number 9, surpassing The New York Times (No. 10) and Apple (No. 11). This marked a significant increase over January 2006, when the rank was 33rd, with Wikipedia receiving around 18.3 million unique visitors.[44] As of March 2020, Wikipedia ranked 13th[4] among websites in terms of popularity according to Alexa Internet. In 2014, it received eight billion page views every month.[45] On February 9, 2014, The New York Times reported that Wikipedia has 18 billion page views and nearly 500 million unique visitors a month, "according to the ratings firm comScore".[46] Loveland and Reagle argue that, in process, Wikipedia follows a long tradition of historical encyclopedias that accumulated improvements piecemeal through "stigmergic accumulation".[47][48]



Wikipedia blackout protest against SOPA on January 18, 2012
On January 18, 2012, the English Wikipedia participated in a series of coordinated protests against two proposed laws in the United States Congress—the Stop Online Piracy Act (SOPA) and the PROTECT IP Act (PIPA)—by blacking out its pages for 24 hours.[49] More than 162 million people viewed the blackout explanation page that temporarily replaced Wikipedia content.[50][51]

On January 20, 2014, Subodh Varma reporting for The Economic Times indicated that not only had Wikipedia's growth stalled, it "had lost nearly ten percent of its page views last year. There was a decline of about two billion between December 2012 and December 2013. Its most popular versions are leading the slide: page-views of the English Wikipedia declined by twelve percent, those of German version slid by 17 percent and the Japanese version lost nine percent."[52] Varma added that "While Wikipedia's managers think that this could be due to errors in counting, other experts feel that Google's Knowledge Graphs project launched last year may be gobbling up Wikipedia users."[52] When contacted on this matter, Clay Shirky, associate professor at New York University and fellow at Harvard's Berkman Klein Center for Internet & Society indicated that he suspected much of the page view decline was due to Knowledge Graphs, stating, "If you can get your question answered from the search page, you don't need to click [any further]."[52] By the end of December 2016, Wikipedia was ranked fifth in the most popular websites globally.[53]

In January 2013, 274301 Wikipedia, an asteroid, was named after Wikipedia; in October 2014, Wikipedia was honored with the Wikipedia Monument; and, in July 2015, 106 of the 7,473 700-page volumes of Wikipedia became available as Print Wikipedia. In April 2019, an Israeli lunar lander, Beresheet, crash landed on the surface of the Moon carrying a copy of nearly all of the English Wikipedia engraved on thin nickel plates; experts say the plates likely survived the crash.[54][55] In June 2019, scientists reported that all 16 GB of article text from the English Wikipedia have been encoded into synthetic DNA.[56]

"""
print("text", len(text))


#Loading the english stop words (a, the, and, like etc etc)

stopwords = list(STOP_WORDS)

#This is the model for tokenizing words, i haven't dug deep in this
#but at looking at the outputs I found it is just tokenizing the words
#It is a comprehensive model for tokenizing into words as well as sentences

nlp = spacy.load('en_core_web_sm')

doc = nlp(text)

tokens = [token.text for token in doc]
# print(tokens)

#by looking at the punctuations i found new line wasn't added as punctuation so i added
punctuation = punctuation + '\n'
#print(punctuation)

#Just counting the word freq from the article
#Ignoring punctuations and stopwords
#And storing them in dictionary
word_freq = {}
for word in doc:
    if word.text.lower() not in stopwords:
        if word.text.lower() not in punctuation:
            if word.text not in word_freq.keys():
                word_freq[word.text] = 1
            else:
                word_freq[word.text] += 1


#print(word_freq)

max_freq = max(word_freq.values())
#print(max_freq)

#normalizing the word freq, by dividing the max freq
for word in word_freq.keys():
    word_freq[word] = word_freq[word]/max_freq

#print(word_freq)

#Tokenizing sentences, The sentences were already tokenized by the nlp(text)
sentence_tokens = [sent for sent in doc.sents]
#print(sentence_tokens)

#getting the sentence scores by addind the word freq which are in the sentence
sentence_scores = {}
for sent in sentence_tokens:
    for word in sent:
        if word.text.lower() in word_freq.keys():
            if sent not in sentence_scores.keys():
                sentence_scores[sent] = word_freq[word.text.lower()]
            else:
                sentence_scores[sent] += word_freq[word.text.lower()]

#print(sentence_scores)

#selecting 30% of the total sentences as our summary
select_length = int(len(sentence_tokens)*0.3)

summary = nlargest(select_length, sentence_scores, key = sentence_scores.get)
# print(summary)

final_summary = [word.text for word in summary]
summary = ' '.join(final_summary)

print(summary)
print("SUMMARY LEN", len(summary))
# print(len(summary))





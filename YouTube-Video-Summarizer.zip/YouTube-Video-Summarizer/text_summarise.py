import torch
import json
from transformers import T5Tokenizer, T5ForConditionalGeneration, T5Config
from pprint import pprint
device = torch.device('cuda')
model = T5ForConditionalGeneration.from_pretrained('t5-small').to(device)
tokenizer = T5Tokenizer.from_pretrained('t5-small')
text = """ and if the morning and procedurally is in a november first here on this morning's headlines and now to use story saying he was aware of that agreement with one woman he said he's trying to think that sexual harassment claims and early nineteen nineties the northeast power outage could last for days more than one million homes are still without power to freak out over storm blamed for at least thirty deaths the government was and there is an investigation now went away after jack move that travelers spread some tarmac at the wrong airport the weather seven hours lydia said the small government named the new acting prime minister us educated in here i'm here i'm alice high he promising to improve human rights and respect international law will cause every day the stand in his own defense were waiting for and services in the trial of michael jackson stopped by raf day on wall street the dow plunging more than two hundred point five cents a wave of salomon the dow ended up ten percent fifth identified these fantastic regions bank the latest to reverse the controversy over five dollar monthly charge that leads that america has the only major banks is so keep that beats and to seventy two days after they're made for t. v. dream wedding king cardiac she named chris humphreys calling it quits the realities darnell says that citing irreconcilable that doesn't advise the satellite american morning every weekday starting at six a. m. eastern half of grief """
preprocess_text = text.strip().replace("\n","")
t5_prepared_Text = "summarize: "+preprocess_text
print ("original text preprocessed: \n", preprocess_text)
tokenized_text = tokenizer.encode(t5_prepared_Text, return_tensors="pt").to(device)
summary_ids = model.generate(tokenized_text,
                                    num_beams=4,
                                    no_repeat_ngram_size=2,
                                    min_length=30,
                                    max_length=100,
                                    early_stopping=True)
output = tokenizer.decode(summary_ids[0], skip_special_tokens=True)
print ("\n\nSummarized text: \n",output)



